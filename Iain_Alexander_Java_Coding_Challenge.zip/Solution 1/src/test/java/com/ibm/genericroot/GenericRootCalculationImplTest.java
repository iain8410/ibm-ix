package com.ibm.genericroot;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GenericRootCalculationImplTest {

	@Test
	void testFindGenericRoot() {
		GenericRootCalculation genericRoot = new GenericRootCalculationImpl();
		assertEquals(9, genericRoot.findGenericRoot(4563));
		
		assertEquals(8, genericRoot.findGenericRoot(98765));
	}

}
