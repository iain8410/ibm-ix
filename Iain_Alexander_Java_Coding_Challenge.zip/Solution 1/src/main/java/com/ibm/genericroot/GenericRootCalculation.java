package com.ibm.genericroot;

public interface GenericRootCalculation {

	public int findGenericRoot(Integer number);
}
