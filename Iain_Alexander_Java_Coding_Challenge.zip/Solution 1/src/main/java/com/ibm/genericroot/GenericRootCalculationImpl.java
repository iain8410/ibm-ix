package com.ibm.genericroot;

public class GenericRootCalculationImpl implements GenericRootCalculation {

	@Override
	public int findGenericRoot(Integer number) {
		Integer genericRoot = 0;
		Integer sumOfDigits = 0;
		StringBuilder sbr = new StringBuilder( String.valueOf(number) );
		
		do
		{
			char [] characterDigits =  sbr.toString().toCharArray();
			sbr.delete(0, sbr.length());
			
			for (int i=0;i < characterDigits.length;i++) {
				sumOfDigits += Integer.valueOf( Character.toString(characterDigits[i]) );
			}
			
			sbr.append( String.valueOf(sumOfDigits) );
			genericRoot = (Integer) sumOfDigits;
			sumOfDigits = 0;
		} while (genericRoot > 9);
		
		return genericRoot;
	}

}
