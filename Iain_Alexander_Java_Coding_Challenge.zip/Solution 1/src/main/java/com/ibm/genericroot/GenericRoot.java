package com.ibm.genericroot;

public class GenericRoot {

	public static void main(String[] args) {
		try {
			Integer number = Integer.parseInt(args[0]);
			GenericRootCalculation genericRootCalculation = new GenericRootCalculationImpl();
			System.out.println( genericRootCalculation.findGenericRoot(number) );
		}
		catch (NumberFormatException nfe) {
			nfe.printStackTrace();
			System.exit(-10);
		}
	}

}
