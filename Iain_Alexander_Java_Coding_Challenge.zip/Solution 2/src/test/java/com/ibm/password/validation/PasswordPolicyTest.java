package com.ibm.password.validation;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ibm.password.Application;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(value = "SpringBootTest.WebEnvironment.DEFINED_PORT",
		  classes = Application.class)
public class PasswordPolicyTest {
	
	@Autowired
	private PasswordPolicyValidator passwordValidator;

	/** Expected password policy for a valid password
	 * 
	 * Alphabets between A-Z or a-z (inclusive) are allowed
	 * The number of alphabets should not be less than 4
	 * Numbers between 0-9 (inclusive) are allowed
	 * The count of numbers in the password should not be less than 2
	 * 
	 */
	@Test
	public void testPasswordValidation() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Password12");
		assertEquals(true, bValid);
	}
	
	@Test
	public void testBelowMinLength() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Pas");
		assertEquals(false, bValid);
	}
	
	@Test
	public void testAtMinLength() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Pass12");
		assertEquals(true, bValid);
	}
	
	@Test
	public void testDoesntHaveAnyNumbers() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("PassMeNow");
		assertEquals(false, bValid);
	}
	
	@Test
	public void testDoesntHaveEnoughNumbers() {		
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Pass7");
		assertEquals(false, bValid);
	}
	
	@Test
	public void testDoesntHaveEnoughCharacters() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("8410");
		assertEquals(false, bValid);
	}
	
	@Test
	public void testStartsWithNumbers() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("84HackMYpasswrd");
		assertEquals(true, bValid);
	}
	
	@Test
	public void testContainsEmbeddedNumbers() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Your6Pas2word");
		assertEquals(true, bValid);
	}
	
	@Test
	public void testContainsContinguousEmbeddedNumbers() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("Your62word");
		assertEquals(true, bValid);
	}
	
	@Test
	public void testContainsNonContinguousEmbeddedLetters() {
		boolean bValid = passwordValidator.isPasswordMeetingPolicy("go3opj5");
		assertEquals(true, bValid);
	}
}
