package com.ibm.password.validation;

public interface PasswordPolicyValidator {

	public boolean isPasswordMeetingPolicy(String password);
}
