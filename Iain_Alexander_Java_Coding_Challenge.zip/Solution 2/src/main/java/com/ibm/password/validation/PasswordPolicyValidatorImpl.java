package com.ibm.password.validation;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.ibm.password.model.PasswordPolicy;

/** This class will validate a password policy meets the following criteria
 * 
 * Alphabets between A-Z or a-z (inclusive) are allowed
 * The number of alphabets should not be less than 4
 * Numbers between 0-9 (inclusive) are allowed
 * The count of numbers in the password should not be less than 2
 *
 */
public class PasswordPolicyValidatorImpl implements PasswordPolicyValidator {
	
	private String alphaCheck = "\\D";
	private String numericCheck = "\\d";
	
	private int MIN_ALPHA_CHARACTERS = 4;
	private int MIN_NUMERIC_DIGITS = 2;

	public boolean isPasswordMeetingPolicy(String password) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		PasswordPolicy passwordPolicy = new PasswordPolicy(password);
		Set<ConstraintViolation<PasswordPolicy>> violations = validator.validate(passwordPolicy);
		if (violations.size() > 0){
			return false;
		}
		
		Pattern pattern = Pattern.compile(alphaCheck);
		Matcher matcher = pattern.matcher(password);
		int alphaCount = 0;
		while (matcher.find()){
			alphaCount++;
		}
		if (alphaCount < MIN_ALPHA_CHARACTERS){
			return false;
		}
		
		pattern = Pattern.compile(numericCheck);
		matcher = pattern.matcher(password);
		int numericCount = 0;
		
		while (matcher.find()){
			numericCount++;
		}
		
		return numericCount >= MIN_NUMERIC_DIGITS;
	}

}
