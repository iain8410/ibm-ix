package com.ibm.password.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PasswordResponse {

	@JsonProperty("password_validity")
	private String passwordValidity;

	public String getPasswordValidity() {
		return passwordValidity;
	}

	public void setPasswordValidity(String passwordValidity) {
		this.passwordValidity = passwordValidity;
	}

}
