package com.ibm.password.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PasswordRequest {

	@JsonProperty("password")
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
