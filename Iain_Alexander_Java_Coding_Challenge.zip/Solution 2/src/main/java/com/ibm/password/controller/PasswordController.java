package com.ibm.password.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.password.model.PasswordRequest;
import com.ibm.password.model.PasswordResponse;
import com.ibm.password.validation.PasswordPolicyValidator;

@RestController
public class PasswordController {
	
	@Autowired
	private PasswordPolicyValidator passwordValidatorService;
	
	@Autowired
	private MessageSource messageSource;
	
	@PostMapping("/password")
	public PasswordResponse searchByName(@RequestBody PasswordRequest passwordRequest){
		PasswordResponse passwordResponse = new PasswordResponse();
		
		boolean isValid = passwordValidatorService.isPasswordMeetingPolicy(passwordRequest.getPassword());
		if (isValid) {
			passwordResponse.setPasswordValidity( messageSource.getMessage("valid_message", null, LocaleContextHolder.getLocale()));
		}
		else {
			passwordResponse.setPasswordValidity( messageSource.getMessage("invalid_message", null, LocaleContextHolder.getLocale()));
		}
		
		return passwordResponse;
	}
	
}
