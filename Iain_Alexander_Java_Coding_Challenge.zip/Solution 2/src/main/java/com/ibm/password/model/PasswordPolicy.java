package com.ibm.password.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PasswordPolicy {

	@NotNull()
	@Size(min=6)
	private String password;

	public String getPassword() {
		return password;
	}

	public PasswordPolicy(String password) {
		super();
		this.password = password;
	}
	
}
